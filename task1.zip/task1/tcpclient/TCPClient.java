package tcpclient;
import java.net.*;
import java.io.*;

public class TCPClient {
    Socket s;

    public TCPClient() {
    }

    public byte[] askServer(String hostname, int port, byte [] toServerBytes) throws IOException {
        TCPClient client = new TCPClient(); //Create a new TCPClient

        client.s = new Socket(hostname, port); //Create a new socket connected to the server with the appropriate port no.
        
        OutputStream sendout = client.s.getOutputStream();
        sendout.write(toServerBytes); //Write all bytes to be sent into a byte array 
        sendout.flush(); //Send all bytes to the server

        InputStream responsein = client.s.getInputStream(); //Create an input stream from the server

        ByteArrayOutputStream responseBuffer = new ByteArrayOutputStream(); //Dynamic byte array buffer used to store all bytes read from the server
        byte [] fixedbuffer = new byte[4096]; //Fixed byte array used in the read operation
        
        int bytesRead; //Tells us the number of bytes actually read into fixedbuffer
        while ((bytesRead = responsein.read(fixedbuffer)) != -1) {
            responseBuffer.write(fixedbuffer, 0, bytesRead);
        } //in.read(fixedbuffer) is used to read some number of bytes from the input stream and store that in fixedbuffer, and then return the no. of bytes read
        
        byte[] responseBytes = responseBuffer.toByteArray(); //Convert response to byte array
        
        client.s.close(); //Close the socket when done
        
        return responseBytes; //Return the response from the server
    }
}

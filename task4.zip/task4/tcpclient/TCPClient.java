package tcpclient;
import java.net.*;
import java.io.*;

public class TCPClient {
    boolean shutdown;
    Integer timeout;
    Integer limit;

    public TCPClient(boolean shutdown, Integer timeout, Integer limit) {
        this.shutdown = shutdown;
        this.timeout = timeout;
        this.limit = limit;
    }

    public byte[] askServer(String hostname, int port, byte[] toServerBytes) throws IOException {
        Socket sock = new Socket(hostname, port);

        OutputStream sendout = sock.getOutputStream();
        sendout.write(toServerBytes);
        sendout.flush();
        
        if(shutdown) {
            sock.shutdownOutput();
        }
        
        InputStream responsein = sock.getInputStream();
        ByteArrayOutputStream responseBuffer = new ByteArrayOutputStream();
        byte[] fixedbuffer = new byte[4096];
        int bytesRead;
        
        try {
            if(timeout != null) {
                sock.setSoTimeout(timeout);
            }
            while((bytesRead = responsein.read(fixedbuffer)) != -1) {
                responseBuffer.write(fixedbuffer, 0, bytesRead);
                if(limit != null && responseBuffer.size() >= limit) {
                    break;
                }
            }
        } 
        catch(SocketTimeoutException e) {
        } 
        finally {
            responsein.close();
            sendout.close();
            sock.close();
        }
        
        return responseBuffer.toByteArray();
    }
}
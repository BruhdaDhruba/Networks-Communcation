import java.net.*;
import java.io.*;
import tcpclient.TCPClient;

public class HTTPAsk {
   
    public static void main( String[] args) throws Exception {
        int port = Integer.valueOf(args[0]);
        ServerSocket server = new ServerSocket(port);
        Socket client;

        while(true){
        client = server.accept();
        String responsecode = "HTTP/1.1 200 OK";
        String responsebody = "test";
        boolean errorflag = false;
        OutputStream clientout = client.getOutputStream();
        InputStream clientin = client.getInputStream();

        int binarydatabyte = clientin.read();
        StringBuilder clientrequestBuilder = new StringBuilder();
            
        while (true) {
            clientrequestBuilder.append((char) binarydatabyte);
            if (clientrequestBuilder.toString().endsWith("\r\n\r\n")) {
                break;
            }
            binarydatabyte = clientin.read();
        }

        String clienthost = null;
        Integer clientport = null;
        Integer clientlimit = null;
        Integer clienttimeout = null;
        Boolean clientshutdown = false;
        String clientstring = null;

        String clientrequest = clientrequestBuilder.toString();
        String GETline = clientrequest.split("\n")[0];
        String Hostline = clientrequest.split("\n")[1].trim();
        String method = GETline.split(" ")[0].trim();
        String version = GETline.split(" ")[2].trim();
        
        try {
            if (!GETline.split(" ")[1].split("\\?")[0].equals("/ask")){
                throw new Exception("InvalidAskException");
            }
        } catch(Exception e) {
            if(!errorflag){
            responsecode = "HTTP/1.1 404 Not Found";
            errorflag = true;
            }
        }
        try{
            if (!method.equals("GET")){
                throw new Exception("InvalidMethodException");
            }
            if (!version.equals("HTTP/1.1")){
                throw new Exception("WrongVersionException");
                }
            if (!Hostline.equals("Host: localhost:" + port)){
                throw new Exception("BadHostException");
                }
        } catch(Exception e) {
            if(!errorflag){
            responsecode = "HTTP/1.1 400 Bad Request";
            errorflag = true;
            }
        }

        String querystring = null;
        String paramstring = null;
        String [] params = null;

        try {
         querystring = GETline.split(" ")[1].trim();
         paramstring = querystring.split("\\?")[1];
         params = paramstring.split("&");
        } catch(Exception e){
            if(!errorflag){
                responsecode = "HTTP/1.1 400 Bad Request";
                errorflag = true;
            }
        }
        try{
            for (String e : params) {
                String param = e.split("=")[0];
                String value = e.split("=")[1];
        
                switch (param) {
                    case "hostname":
                        clienthost = value;
                        break;
                    case "limit":
                        clientlimit = Integer.valueOf(value);
                        break;
                    case "shutdown":
                        clientshutdown = Boolean.valueOf(value);
                        break;
                    case "timeout":
                        clienttimeout = Integer.valueOf(value);
                        break;
                    case "port":
                        clientport = Integer.valueOf(value);
                        break;
                    case "string":
                        clientstring = value + "\n";
                        break;
                    default:
                        // Handle unknown parameters or ignore them
                        break;
                }
            }
        } catch(Exception e) {
            if(!errorflag){
            responsecode = "HTTP/1.1 400 Bad Request";
            errorflag = true;
            }
        }

        byte[] serverBytes = null;
        try 
        {
            TCPClient tcpClient = new TCPClient(clientshutdown, clienttimeout, clientlimit);

            if (clientstring == null) {
                serverBytes = tcpClient.askServer(clienthost, clientport, "".getBytes());
                
            } else {
                serverBytes = tcpClient.askServer(clienthost, clientport, clientstring.getBytes());
            }
        } catch (Exception e) {
             if (e instanceof UnknownHostException) {
                if(!errorflag){
                    responsecode = "HTTP/1.1 404 Not Found";
                    errorflag = true;
                }
            } else {
                if(!errorflag){
                    responsecode = "HTTP/1.1 400 Bad Request";
                    errorflag = true;
                }
            }
        }
        if (serverBytes != null)
            responsebody = new String(serverBytes);
        else
            responsebody = "";
        if (responsecode.equals("HTTP/1.1 404 Not Found") || responsecode.equals("HTTP/1.1 400 Bad Request")){
            responsebody = "";
        }
        String response = String.format("%s\r\n\r\n%s", responsecode, responsebody);

        clientout.write(response.getBytes());
        clientout.flush();
        clientout.close();
        clientin.close();
        client.close();
        //server.close();
    }
    }

}


